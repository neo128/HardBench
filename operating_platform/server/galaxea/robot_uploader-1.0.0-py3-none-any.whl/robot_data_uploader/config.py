# 配置文件
import os
import sys
import json


# NOTE:测试
SERVER_URL = "http://120.92.91.171:30083"
# 线上
# SERVER_URL = "http://ei2rmd.baai.ac.cn" 

TOKEN_PATH = "/api/eai/userAccessKey/getAccessToken"
STS_PATH =  "/api/eai/userAccessKey/getKs3AccessKey"
TASK_PATH = "/api/eai/task"
START_UPLOAD_PATH = "/api/eai/dataset/upload/start"
UPDATE_UPLOAD_PATH = "/api/eai/dataset/upload/process"
COMPLETE_UPLOAD_PATH = "/api/eai/dataset/upload/complete"


ENDPOINT = "ks3-cn-beijing.ksyun.com"
# NOTE:测试
BUCKET_NAME = "baai-eai-datasets-test"
# 线上
# BUCKET_NAME = "baai-eai-datasets" 

UPLOAD_TARGET = "data"

# 配置文件路径
USER_CONFIG_DIR = os.path.expanduser("~/.robot_uploader")
USER_CONFIG_FILE = os.path.join(USER_CONFIG_DIR, "config.json")

def load_user_config():
    """加载用户配置，如果配置文件不存在则创建默认配置"""
    try:
        # 确保配置目录存在
        if not os.path.exists(USER_CONFIG_DIR):
            os.makedirs(USER_CONFIG_DIR)
            
        # 如果配置文件不存在，创建默认配置
        if not os.path.exists(USER_CONFIG_FILE):
            default_config = {
                "SERVER_URL": SERVER_URL,
                "ENDPOINT": ENDPOINT,
                "BUCKET_NAME": BUCKET_NAME,
                "UPLOAD_TARGET": UPLOAD_TARGET,
            }
            
            with open(USER_CONFIG_FILE, "w", encoding="utf-8") as f:
                json.dump(default_config, f, indent=4)
            print(f"已创建默认配置文件: {USER_CONFIG_FILE}")
            print("请编辑此文件设置您的访问密钥和其他配置")
            return
            
        # 加载配置文件
        with open(USER_CONFIG_FILE, "r", encoding="utf-8") as f:
            user_config = json.load(f)
            
        # 更新全局配置
        for key, value in user_config.items():
            if key in globals():
                globals()[key] = value
                
    except Exception as e:
        print(f"配置文件加载失败: {str(e)}")
        print("将使用默认配置")

# 加载用户配置
# load_user_config() 