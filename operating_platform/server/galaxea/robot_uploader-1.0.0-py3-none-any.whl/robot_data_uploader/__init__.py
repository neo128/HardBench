"""机器人数据上传工具"""

__version__ = "0.2.0"
__author__ = "BAAI DataPlatform"
# __license__ = "Apache-2.0" 