"""允许通过 python -m robot_data_uploader 运行程序"""
from robot_data_uploader.uploader import main

if __name__ == "__main__":
    main() 